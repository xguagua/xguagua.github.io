#include <bits/stdc++.h>
#define int long long
using namespace std;

signed main()
{
    ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
    return 0;
}