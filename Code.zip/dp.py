from random import randrange as rd
from sys import argv
from os import popen,system

d,s = 0,0
r = ""
for _ in range(int(argv[1])):
    flg = True
    data = open("data","w")
    q = rd(1,99) 
    n = rd(q + 1,100)
    data.write(f"{n} {q}\n")
    for i in range(q):
        k = rd(2,100)
        data.write(f"{k}\n")
    data.close()
    system("c.exe < data > c.out")
    system("c_des.exe < data > cb.out")
    c,cb = open("c.out","r"),open("cb.out","r")
    if(c.read() == cb.read()):
        r = "Same"
        s += 1
    else:
        r = "Diff"
        d += 1
    print(f"Test:{_} over!{r}!")
print(f"Diff:{d} Same:{s}")